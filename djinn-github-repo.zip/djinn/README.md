# DJINN

An experimental, visual network architecture prototype.

Core flow:

**Discover → Negotiate → Verify → Deliver → Confirm**

The prototype lets you:
- discover routes between nodes
- send messages through discovered paths
- disable nodes and observe topology changes
- revive nodes
- inspect the protocol log

## Run

Open `index.html` in a modern browser.

This prototype is intentionally self-contained: no server, dependencies, or build step are required.
